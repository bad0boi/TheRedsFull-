<?php $__env->startSection('playerDetails'); ?>



    <!--Single specific ID Article VIEW page-->

    <div id="wrapper" class="p-5">

        <div class="container w-50" style="text-align: center;">
            <div id="shoutView">
                <h1><?php echo e($squad->name); ?></h1>
                <h2>2019/2020 Season</h2>
                    <p>Age: <?php echo e($squad->age); ?></p>
                        <p> Nationality: <?php echo e($squad->nationality); ?></p>
                            <p>Position: <?php echo e($squad->position); ?></p>
                                <p>Height: <?php echo e($squad->height); ?></p>
                                    <p>Jersey: <?php echo e($squad->jersey); ?></p>
                                <h2>Premier League Record: </h2>
                                        <p>Goals: <?php echo e($squad->goals); ?></p>
                                            <p>Assists: <?php echo e($squad->assists); ?></p>
                                                <a href="<?php echo e($squad->social); ?>" target="_blank"><?php echo e($squad->social); ?></a>
            </div>
        </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/prototype/resources/views/squads/show.blade.php ENDPATH**/ ?>