<?php $__env->startSection('welcome'); ?>


<!-- LOGIN SECTION @ The top right of the screen  -->
<div class="flex-center position-ref full-height">
    <?php if(Route::has('login')): ?>
        <div class="top-right links">
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(url('/home')); ?>">Home</a>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>">Login</a>

                <?php if(Route::has('register')): ?>
                    <a href="<?php echo e(route('register')); ?>">Become an LFC speaker</a>
                <?php endif; ?>
            <?php endif; ?>
        </div>
<?php endif; ?>



<!--BODY-->

    <div class="content">

        <div class=" m-b-md p-5">
            <div class="container">
            <img src="/svg/TheRedsLogo.svg" style="max-height: 300px; max-width: 200px;" alt="">
            </div>
            <br>
            <!-- User logged-in information -->

            <div class="alert alert-success" role="alert">
                <?php if(auth()->guard()->check()): ?>
                    Alright, <?php echo e(Auth::user()->name); ?> mate.
                <?php else: ?>
                    Welcome, you must register to see content.
                <?php endif; ?>
            </div>



            <div id="welcomeInfo" class="container">
                <div class="row alert alert-light" role="alert">
                    <div class="col-sm">
                        The home of the most exclusive LFC family

                    </div>
                    <div class="col-sm">
                        Ensuring to accommodate the most passionate LFC family
                    </div>
                    <div class="col-sm">
                        Enjoy entertaining and informative content exclusively
                    </div>



                </div>


            </div>
        </div>












    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/prototype/resources/views/welcome.blade.php ENDPATH**/ ?>