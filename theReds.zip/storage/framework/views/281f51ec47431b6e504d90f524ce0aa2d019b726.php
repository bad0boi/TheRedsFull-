<?php $__env->startSection('profile'); ?>

    <div class="wrapper p-5">


        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>

                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <li> <?php echo e($error); ?></li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
            </div>
        <?php endif; ?>

    <!-- Sessions flash feature + message -->

        <?php if(session()->get('message')): ?>
            <div class="alert alert-success" role="alert">
                <strong>Success:</strong> <?php echo e(session()->get('message')); ?>

            </div>
    <?php endif; ?>


    <!-- Shouts feature banner -->


        <div class="alert alert-primary" role="alert">

            <a href="/articles"> Check out the latest <strong>Shouts</strong> from other <strong>users</strong> </a>

        </div>

        <div class="row"> <!-- 3 Columns Row-->

            <!-- Avatar Section -->

            <div id="profile-sidebar" class="col-sm">
                <div class="card">
                    <div style="color: indianred; text-align: center;" class="card-header font-weight-bold"> Avatar</div>
                    <br>

                    <img src="/images/avatar/<?php echo e(Auth::user()->avatar); ?>" alt="profile_picture" style="height: 100px;
                            border-radius: 50%; margin: 20px;">


                </div>

                <br>

                <!-- Sidebar -->

                <div class="card">
                    <div style="color: indianred; text-align: center;" class="card-header font-weight-bold"> Username: <?php echo e(Auth::user()->name); ?></div>
                    <br>
                    <a href="/home" class="btn btn-primary btn-block">Home</a>
                    <a href="<?php echo e(route('changepassword')); ?>" class="btn btn-primary btn-block">Change Password</a>
                    <a href="/news" class="btn btn-primary btn-block">News</a>
                    <a href="/home" class="btn btn-primary btn-block">Next Game</a>
                    <a href="/articles/create" class="btn btn-primary btn-block">Shout</a>



                </div>

                <br>

            </div>
            <div class="col-md">

                <!-- MAIN Profile Card -->

                <div id="profile-card" class="col-md-9">
                    <div class="card">
                        <div class="card-header"> <?php echo e(Auth::user()->name); ?>'s Dashboard</div>
                        <div class="card-body">
                            <?php if(session('status')): ?>
                                <div class="alert alert-success" role="alert">  <?php echo e(session('status')); ?>   </div>
                        <?php endif; ?>

                        <!-- User ID -->

                            <div class="form-group">
                                <label for="name"> <strong>ID: <?php echo e(Auth::user()->id); ?>   </strong></label>
                            </div>

                         <!-- User Profile Picture/Avatar upload -->

                            <form enctype="multipart/form-data" action="<?php echo route('profileavatar'); ?>" method="post">


                                <div class="form-group">
                                    <input type="file" name="avatar" class="form-control">
                                    <input type="hidden" class="form-control"  name="_token" value="<?php echo e(csrf_token ()); ?>" >

                                <!-- Update Button -->

                                    <br>

                                <button class="btn btn-primary" type="submit">Upload Avatar</button>


                            </form>
                        </div>


                    </div>
                </div>




            </div>



        </div>
    </div>
    </div>
    </div>










<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/prototype/resources/views/profilepicture.blade.php ENDPATH**/ ?>