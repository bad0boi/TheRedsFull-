<?php $__env->startSection('news'); ?>



    <div id="wrapper" class="p-5">

        <div class="container">

            <h1>The Reds Squad</h1>
            <small>Internal Database</small>
            <p>Admin: <?php echo e(Auth::user()->name); ?></p>
            <br>

            <form method="POST" action="/squads">
            <?php echo csrf_field(); ?> <!--cross site request forgery ref: 419 error-->


                <div class="form-group">
                    <label for="title">Name</label>
                    <input
                        class="form-control"
                        id="name"
                        name="name"
                        placeholder="Players Name"
                        value="<?php echo e(old('name')); ?>"> <!--ID and name essential-->

                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p style="color: red;"> <?php echo e($errors->first('name')); ?></p>  <!--:error is Laravels very own validation component, though you can add 'required'
                                                            in the input markup to also enable validation via browser-->
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="excerpt">Age</label>

                    <input class="form-control"
                           type="number"
                           id="age"
                           name="age"
                           placeholder="Age"
                           value="<?php echo e(old('age')); ?>"> <!-- 'old' is Laravels function of keeping the input in the form when
                                                               the form isn't completed / keeping the previous input value-->

                    <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p style="color: red;"> <?php echo e($errors->first('age')); ?></p>  <!--:error is Laravels very own validation component, though you can add 'required'
                                                            in the input markup to also enable validation via browser-->
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                <div class="form-group">

                    <label for="body">Nationality</label>

                    <input class="form-control"
                           name="nationality"
                           id="nationality"
                           placeholder="Players Nationality"
                           value="<?php echo e(old('nationality')); ?>">

                    <?php $__errorArgs = ['nationality'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p style="color: red;"> <?php echo e($errors->first('nationality')); ?></p>  <!--:error is Laravels very own validation component, though you can add 'required'
                                                            in the input markup to also enable validation via browser-->
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <div class="form-group">

                    <label for="body">Position</label>

                    <input class="form-control"
                           name="position"
                           id="position"
                           placeholder="Players Position"
                           value="<?php echo e(old('position')); ?>">

                    <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p style="color: red;"> <?php echo e($errors->first('position')); ?></p>  <!--:error is Laravels very own validation component, though you can add 'required'
                                                            in the input markup to also enable validation via browser-->
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <div class="form-group">

                    <label for="body">Height</label>

                    <input class="form-control"
                           name="height"
                           id="height"
                           placeholder="Players height"
                           value="<?php echo e(old('height')); ?>">

                    <?php $__errorArgs = ['height'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p style="color: red;"> <?php echo e($errors->first('height')); ?></p>  <!--:error is Laravels very own validation component, though you can add 'required'
                                                            in the input markup to also enable validation via browser-->
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <div class="form-group">

                    <label for="body">Jersey Number</label>

                    <input type="number" class="form-control"
                           name="jersey"
                           id="jersey"
                           placeholder="Jersey Number"
                           value="<?php echo e(old('jersey')); ?>">

                    <?php $__errorArgs = ['jersey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p style="color: red;"> <?php echo e($errors->first('jersey')); ?></p>  <!--:error is Laravels very own validation component, though you can add 'required'
                                                            in the input markup to also enable validation via browser-->
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <div class="form-group">

                    <label for="body">Goals</label>

                    <input type="number" class="form-control"
                           name="goals"
                           id="goals"
                           placeholder="Players Goals"
                           value="<?php echo e(old('goals')); ?>">

                    <?php $__errorArgs = ['goals'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p style="color: red;"> <?php echo e($errors->first('goals')); ?></p>  <!--:error is Laravels very own validation component, though you can add 'required'
                                                            in the input markup to also enable validation via browser-->
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <div class="form-group">

                    <label for="body">Assists</label>

                    <input type="number" class="form-control"
                           name="assists"
                           id="assists"
                           placeholder="Players assists"
                           value="<?php echo e(old('assists')); ?>">

                    <?php $__errorArgs = ['assists'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p style="color: red;"> <?php echo e($errors->first('assists')); ?></p>  <!--:error is Laravels very own validation component, though you can add 'required'
                                                            in the input markup to also enable validation via browser-->
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <div class="form-group">

                    <label for="body">Players Social Links</label>

                    <textarea type="text" class="form-control"
                           name="social"
                           id="social"
                           placeholder="Players social"
                              value="<?php echo e(old('assists')); ?>"> </textarea>

                    <?php $__errorArgs = ['social'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p style="color: red;"> <?php echo e($errors->first('social')); ?></p>  <!--:error is Laravels very own validation component, though you can add 'required'
                                                            in the input markup to also enable validation via browser-->
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>







                <!-- Submit Button -->

                <button type="submit" class="btn btn-primary">Submit</button>

            </form>




        </div>
    </div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/prototype/resources/views/squads/create.blade.php ENDPATH**/ ?>