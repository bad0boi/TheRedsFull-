<?php $__env->startSection('test'); ?>

    <!--NAVBAR-->


    <div class="news-container">
        <h2> Article: News </h2>
        <h3>by The Reds </h3>
    </div>




<?php $__env->stopSection(); ?>







<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/prototype/resources/views/test.blade.php ENDPATH**/ ?>