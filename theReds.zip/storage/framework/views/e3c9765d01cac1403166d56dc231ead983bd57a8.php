<?php $__env->startSection('allusers'); ?>



    <!-- Search Bar -->








    <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="wrapper">
            <div id="allUsersSection" class="container" style="background-color: #f7f7f7;">
                <div id="userSection" class="p-2">
                    <img id="avatar" style="height: 50px; width: 50px;" src="/images/avatar/<?php echo e($profile->avatar); ?>">
                        <a href="/profile/<?php echo e($profile->id); ?>"> <h1 style="color: #2C383B;"> @ <?php echo e($profile->name); ?></h1> </a>


                </div>
            </div>
        </div>








    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/prototype/resources/views/allusers.blade.php ENDPATH**/ ?>