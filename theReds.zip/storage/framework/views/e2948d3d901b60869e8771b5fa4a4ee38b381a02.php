<?php $__env->startSection('profile'); ?>

    <div class="wrapper p-5">


        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>

                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <li> <?php echo e($error); ?></li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
            </div>
        <?php endif; ?>

        <!-- Password Error flash -->

            <?php if(session('error')): ?>

                <div class="alert alert-danger" role="alert">
                    <?php echo e(session ('error')); ?>

                </div>

                <?php endif; ?>

    <!-- Sessions flash feature + message -->

        <?php if(session()->get('message')): ?>
            <div class="alert alert-success" role="alert">
                <strong>Success:</strong> <?php echo e(session()->get('message')); ?>

            </div>
    <?php endif; ?>


    <!-- Shouts feature banner -->


        <div class="alert alert-primary" role="alert">

            <a href="/articles"> Check out the latest <strong>Shouts</strong> from other <strong>users</strong> </a>

        </div>

        <div class="row"> <!-- 3 Columns Row-->

            <!-- Avatar Section -->

            
            
            


            <div id="profile-sidebar" class="col-sm">


                <!-- Sidebar -->

                <div class="card">
                    <div style="color: indianred; text-align: center;" class="card-header font-weight-bold"> Username: <?php echo e(Auth::user()->name); ?></div>
                    <br>
                    <a href="/home" class="btn btn-primary btn-block">Home</a>
                    <a href="/profile" class="btn btn-primary btn-block">Profile</a>
                    <a href="/news" class="btn btn-primary btn-block">News</a>
                    <a href="/home" class="btn btn-primary btn-block">Next Game</a>
                    <a href="/articles/create" class="btn btn-primary btn-block">Shout</a>



                </div>

            </div>
            <div class="col-md">

                <!-- MAIN Profile Card -->

                <div id="profile-card" class="col-md-9">
                    <div class="card">
                        <div class="card-header"> <?php echo e(Auth::user()->name); ?>'s Dashboard</div>
                        <div class="card-body">
                            <?php if(session('status')): ?>
                                <div class="alert alert-success" role="alert">  <?php echo e(session('status')); ?>   </div>
                        <?php endif; ?>

                        <!-- User ID -->

                            <div class="form-group">
                                <label for="name"> <strong>ID: <?php echo e(Auth::user()->id); ?>   </strong></label>
                            </div>

                            <!-- FORM -->

                            <form action="<?php echo route('changepassword'); ?>" method="post">
                                <?php echo csrf_field(); ?>


                                <!-- Current Password -->

                                <div class="form-group">
                                    <label for="current_password"> <strong>Current Password </strong></label>
                                    <input type="password" class="form-control" id="current_password" name="current_password">

                                </div>

                                    <!-- New Password -->

                                    <div class="form-group">
                                        <label for="new_password"> <strong>New Password: </strong></label>
                                        <input type="password" class="form-control" id="new_password" name="new_password">

                                    </div>

                                    <!-- Confirm New Password -->

                                    <div class="form-group">
                                        <label for="new_password_confirmation"> <strong>Confirm New Password </strong></label>
                                        <input type="password" class="form-control" id="new_password_confirmation" name="new_password_confirmation">

                                    </div>

                                <!-- Change Password Update Button -->

                                <button class="btn btn-primary" type="submit">Change Password </button>


                            </form>
                        </div>


                    </div>
                </div>




            </div>



        </div>
    </div>
    </div>
    </div>










<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/prototype/resources/views/changepassword.blade.php ENDPATH**/ ?>