<?php $__env->startSection('news'); ?>



    <!--Single specific ID Article VIEW page-->

    <div id="wrapper" class="p-5">

        <div class="container">
            <div id="shoutView">
                <h1 style="color: #2C383B;"><?php echo e($article->title); ?></h1>
                    <h2><?php echo e($article->excerpt); ?></h2>
                         <p> <?php echo e($article->body); ?>  </p>
                              <a href="/profile/<?php echo e($article->user_id); ?>"> <p> Shouted by userID: <?php echo e($article->user_id); ?> </a> </p>
                                    <small>Created at <?php echo e($article->created_at); ?></small>
                                <br>

                                         <!-- Tags section-->
                                <h3> Tags</h3>
                                    <p>
                                        <?php $__currentLoopData = $article->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <a href="/articles?tag=<?php echo e($tag->name); ?>"> ,<?php echo e($tag->name); ?></a>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </p>

        </div>
    </div>







<?php $__env->stopSection(); ?>







<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/prototype/resources/views/articles/show.blade.php ENDPATH**/ ?>