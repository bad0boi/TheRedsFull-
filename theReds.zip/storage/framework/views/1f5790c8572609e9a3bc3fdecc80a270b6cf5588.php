<?php $__env->startSection('news'); ?>

    <!-- Show Specific Users Profile Page ref: web.php > ProfileController > 'show' method -->

<div class="wrapper">
        <div id="userProfileView" >

                <div id="profileCard" class="card col-sm p-5" style="width: 18rem; left: 40%;">
                    <img id="avatar" src="/images/avatar/<?php echo e($profile->avatar); ?>" class="card-img-top" alt="...">
                        <form>
                            <div class="form-group">
                                <h3 style="color: black;">@ <?php echo e($profile->name); ?></h3>
                                <small id="emailHelp" class="form-text text-muted">I am a certified member of The Reds family.</small>
                            </div>

                            <div class="form-group">
                                <p style="color: black;">UserID: <?php echo e($profile->id); ?></p>
                            </div>

                            <div class="form-group">
                                <p style="color: black;">Location: <?php echo e($profile->location); ?></p>
                            </div>

                            <div class="form-group">
                                <p style="color: black;">Gender: <?php echo e($profile->gender); ?></>
                            </div>

                            <div class="form-group">
                                <p style="color: black;">Favourite Player: <?php echo e($profile->favouriteplayer); ?></>
                            </div>

                    </form>













                    </div>



                </div>

</div>


















<?php $__env->stopSection(); ?>







<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/prototype/resources/views/profileshow.blade.php ENDPATH**/ ?>