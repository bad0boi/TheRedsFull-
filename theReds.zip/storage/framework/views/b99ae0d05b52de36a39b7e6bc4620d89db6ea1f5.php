<?php $__env->startSection('news'); ?>



    <div id="wrapper" class="p-5">

        <div class="container">

        <h1>Update Article: Somethings changed </h1>
        <br>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_article')): ?>

        <form method="POST" action="/articles/<?php echo e($article->id); ?>">
        <?php echo csrf_field(); ?> <!--cross site request forgery ref: 419 error-->
            <?php echo method_field('PUT'); ?> <!--Hidden request of telling Laravel + Browser to actually do a PUT request as current web browser only
                                really understand GET and POST atm-->


            <div class="form-group">
                <label for="title">Title</label>
                <input class="form-control" id="title" name="title" value="<?php echo e($article->title); ?>"> <!--ID and name essential-->
            </div>

            <div class="form-group">
                <label for="excerpt">Excerpt</label>

                <input class="form-control" type="text" id="excerpt" name="excerpt" value="<?php echo e($article->excerpt); ?>">

            </div>


            <div class="form-group">

                <label for="body">Body</label>

                <textarea class="form-control" name="body" id="body" rows="3"> <?php echo e($article->body); ?></textarea>

            </div>

            <button type="submit" class="btn btn-primary">Update</button>
        </form>

                <?php endif; ?>


        </div>
    </div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/prototype/resources/views/articles/edit.blade.php ENDPATH**/ ?>