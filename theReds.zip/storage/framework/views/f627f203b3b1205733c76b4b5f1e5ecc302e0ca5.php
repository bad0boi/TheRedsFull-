<?php $__env->startSection('contact'); ?>

    <!-- This functionality is using Mail Trap as inbox source for all emails sent via GitHub account -->

    <div id="contact-wrapper">
        <div  class="container p-5">
            <h1 style="color: black;">Contact Us</h1>
                <small> We ensure to reply to every single email sent the members of our community.</small>
                    <small> <br>  If you have any issues or any cause for reaching out,  please provide your email
                    address and we will get back to you as soon as possible.</small>
                        <small>
                            <ul style="color: black; margin-top: 10px;">
                                    <li>Is there something broken?</li>
                                    <li>Are you worried about a user?</li>
                                    <li>Advertisement?</li>
                                    <li>Functionality Issues?</li>
                                </ul>
                                     </small>
            <div class="form-group pt-3">
                <form action="/contact" method="POST">
                    <?php echo csrf_field(); ?> <!-- Ensure this is inside every form not outside of it -->
                        <label for="inputEmail"> E-mail Address</label>
                            <input type="text" id="email" name="email" placeholder="Enter your email"> <br>

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div style="color: red;">
                                        <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <button class="btn-primary" type="submit">Send</button>
                                                <?php if(session('message')): ?>
                                                    <div>
                                                        <p style="color: mediumseagreen;"><?php echo e(session('message')); ?> </p>
                                                    </div>

                                                <?php endif; ?>

                        </form>
                    </div>
        </div>
    </div>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/prototype/resources/views/contact.blade.php ENDPATH**/ ?>