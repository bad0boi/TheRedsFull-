<?php $__env->startSection('news'); ?>



    <div id="wrapper" class="p-5">

        <div class="container">

            <h1>Shout your opinion: How you feeling? </h1>
            <p>User: <?php echo e(Auth::user()->name); ?></p>
        <br>

            <form method="POST" action="/articles">
                <?php echo csrf_field(); ?> <!--cross site request forgery ref: 419 error-->


                <div class="form-group">
                    <label for="title">Title</label>
                    <input
                        class="form-control"
                        id="title"
                        name="title"
                        placeholder="Name of title"
                        value="<?php echo e(old('title')); ?>"> <!--ID and name essential-->

                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p style="color: red;"> <?php echo e($errors->first('title')); ?></p>  <!--:error is Laravels very own validation component, though you can add 'required'
                                                            in the input markup to also enable validation via browser-->
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="excerpt">Excerpt</label>

                    <input class="form-control"
                           type="text"
                           id="excerpt"
                           name="excerpt"
                           placeholder="Reference"
                            value="<?php echo e(old('excerpt')); ?>"> <!-- 'old' is Laravels function of keeping the input in the form when
                                                               the form isn't completed / keeping the previous input value-->

                    <?php $__errorArgs = ['excerpt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p style="color: red;"> <?php echo e($errors->first('excerpt')); ?></p>  <!--:error is Laravels very own validation component, though you can add 'required'
                                                            in the input markup to also enable validation via browser-->
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                <div class="form-group">

                    <label for="body">Body</label>

                    <textarea class="form-control"
                              name="body"
                              id="body"
                              rows="3"
                              placeholder="Hows the team and the players?"
                    value="<?php echo e(old('body')); ?>"></textarea>

                    <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p style="color: red;"> <?php echo e($errors->first('body')); ?></p>  <!--:error is Laravels very own validation component, though you can add 'required'
                                                            in the input markup to also enable validation via browser-->
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                    <!-- Tags section -->

                    <div class="form-group">

                        <label for="body" class="mr-5">Select Tags</label>

                        <select class="form-control" name="tags[]" multiple> <!-- The tags[] input allows selected tags to be stored in an Array as opposed to individually
                                                                  as well as 'multiple' allowing users to select number of tag -->
                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tag->id); ?>"> <?php echo e($tag->name); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <?php $__errorArgs = ['tags'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p style="color: red;"> <?php echo e($errors->first('tags')); ?></p>  <!--:error is Laravels very own validation component, though you can add 'required'
                                                            in the input markup to also enable validation via browser-->
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>



                    <!-- Submit Button -->

                <button type="submit" class="btn btn-primary">Submit</button>

            </form>




        </div>
    </div>





    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/prototype/resources/views/articles/create.blade.php ENDPATH**/ ?>