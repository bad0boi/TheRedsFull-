<?php $__env->startSection('userprofile'); ?>

    <div class="container">

    <div class="col-md">

        <!-- MAIN Profile Card -->

        <div id="profile-card" class="">
            <div class="card">
                <div class="card-header"> <?php echo e(Auth::user()->name); ?>'s Dashboard</div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">  <?php echo e(session('status')); ?>   </div>
                <?php endif; ?>

                <!-- User ID -->

                    <div class="form-group">
                        <label for="name"> <strong>ID: <?php echo e(Auth::user()->id); ?>   </strong></label>
                    </div>

                    <!-- Name -->
                    <form action="<?php echo route('profileupdate'); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <div class="form-group">
                            <label for="name"> <strong>Name: </strong></label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo e(Auth::user()->name); ?>">
                        </div>
                        <!-- Email -->
                        <div class="form-group">
                            <label for="name"> <strong>Email:  </strong></label>
                            <input type="text" class="form-control" id="email" name="email" value="<?php echo e(Auth::user()->email); ?>">
                        </div>

                        <!-- Location -->

                        <div class="form-group">
                            <label for="name"> <strong>Location:  </strong></label>
                            <input type="text" class="form-control" id="location" name="location" value=" <?php echo e(Auth::user()->location); ?>" placeholder="Enter your location ">
                        </div>

                        <!-- Gender -->

                        <div class="form-group">
                            <label for="name"> <strong>Gender:  </strong></label>
                            <input type="text" class="form-control" id="gender" name="gender" value="<?php echo e(Auth::user()->gender); ?>" placeholder="Enter your Gender">
                        </div>

                        <!-- Favourite LFC Player -->

                        <div class="form-group">
                            <label for="name"> <strong>Favourite Player:  </strong></label>
                            <input type="text" class="form-control" id="favouriteplayer" name="favouriteplayer" value="<?php echo e(Auth::user()->favouriteplayer); ?>" placeholder="Enter your favourite player">
                        </div>




                    </form>
                </div>

            </div>
        </div>
    </div>

    </div>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/prototype/resources/views/userprofile.blade.php ENDPATH**/ ?>