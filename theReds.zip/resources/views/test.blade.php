@extends('layout')

@section('test')

    <!--NAVBAR-->


    <div class="news-container">
        <h2> Article: News </h2>
        <h3>by The Reds </h3>
    </div>




@endsection






