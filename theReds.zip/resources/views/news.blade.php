@extends('layout')

@section('news')


   <div class="wrapper">
       <div class="container">
            <div class="homeNewsHeader">
                <h1 style="font-weight: bold;"> city news: </h1>
                  <small>Explore our small contribution to city reportings.</small> <br>
                    <small>Author: Guardian</small>
      </div>
        <div id="liverpoolCityNews" class="row p-5"></div>

           <div class="leagueTable"></div>

       </div>
   </div>






@endsection






